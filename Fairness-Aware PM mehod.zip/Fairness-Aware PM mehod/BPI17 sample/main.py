import pm4py
import os
import pandas as pd
import model
import draw
import numpy as np
import matplotlib.pyplot as plt

from pm4py.algo.discovery.inductive import algorithm as inductive_miner
from pm4py.algo.conformance.alignments.petri_net import algorithm as alignments
from pm4py.algo.evaluation.replay_fitness import algorithm as replay_fitness
from pm4py.objects.conversion.process_tree import converter as process_tree_converter
from pm4py.visualization.petri_net import visualizer as pn_visualizer
from scipy.stats import mannwhitneyu
from pm4py.algo.evaluation.simplicity import algorithm as simplicity_evaluator
from pm4py.algo.evaluation.generalization import algorithm as generalization_evaluator

from scipy.stats import brunnermunzel

if __name__ == "__main__":

    ########## Step 1 Import the model from ProM ############
    net, initial_marking, final_marking = pm4py.read_pnml(os.path.join("Hospital/original.pnml"))

    ############ Step 2 Read Log ###############
    minority = pm4py.read_xes("Hospital/Hospital_CaseT.xes")
    majority = pm4py.read_xes("Hospital/Hospital_CaseF.xes")

    ############ Step 3.1 Calculate the simplicity of the model ###############
    # simp = simplicity_evaluator.apply(net)
    # print("Model simplicity score:", simp)

    ############ Step 3.2 Calculate Precision ###############
    # prec_minority = pm4py.precision_alignments(minority, net, initial_marking, final_marking)
    # prec_minority = pm4py.precision_alignments(majority, net, initial_marking, final_marking)
    # print("Precision scores for minority:", prec_minority)
    # print("Precision scores for majority:", prec_minority)

    ############ Step 3.3 Calculate Generalization ###############
    # gen_minority = generalization_evaluator.apply(minority, net, initial_marking, final_marking)
    # gen_minority = generalization_evaluator.apply(majority, net, initial_marking, final_marking)
    # print("Generalization score for minority:", gen_minority)
    # print("Generalization score for majority:", gen_minority)

    # #process discovery and get model
    # net, initial_marking, final_marking = model.model_discovery()

    # # Visualize the Petri net
    # gviz = pn_visualizer.apply(net, initial_marking, final_marking)
    # # pn_visualizer.view(gviz)

    # # Save the image file to the specified path and file name
    # output_file_path = 'Petri Net/Hiring/original.png'
    # pn_visualizer.save(gviz, output_file_path)

    #For eventlog that id 'time:timestamp' not the date type (Sepsis eventlog)
    # if minority['time:timestamp'].dtype != 'datetime64[ns, UTC]':
    #     minority['time:timestamp'] = pd.to_datetime(minority['time:timestamp'], utc=True)
    #
    # if majority['time:timestamp'].dtype != 'datetime64[ns, UTC]':
    #     majority['time:timestamp'] = pd.to_datetime(majority['time:timestamp'], utc=True)

    ############### Step 4 Calculate Alignment ###############

    #Get all traces alignment results
    # aligned_traces1 = pm4py.conformance_diagnostics_alignments(minority, net, initial_marking, final_marking)
    # aligned_traces2 = pm4py.conformance_diagnostics_alignments(minority, net, initial_marking, final_marking)


    ############### Step 5 Draw boxplot ###############
    # Draw boxplot for each group
    # fitness_values1,fitness_values2 = draw.draw(aligned_traces1, aligned_traces2)


    ############### Step 6.1 Read all fitness values for Mann Whitney U test ###############
    # fitness_values1 = []
    # for alignment1 in aligned_traces1:
    #     if alignment1['fitness'] <= 1.0:
    #         fitness_values1.append(alignment1['fitness'])
    #     else:
    #         print(alignment1)
    #
    # # Declare fitness_values2 to put all fitness in the majority
    # fitness_values2 = []
    # for alignment2 in aligned_traces2:
    #     if alignment2['fitness'] <= 1.0:
    #         fitness_values2.append(alignment2['fitness'])
    #     else:
    #         print(alignment2)

    ################ Step 6.2 Mann Whitney U Test #####################

    #Start to conduct test
    # stat, p_val = mannwhitneyu(fitness_values1, fitness_values2)

    # Sample sizes
    # n1 = 372
    # n2 = 678
    #
    # # Calculate effect size
    # effect_size_r = stat / (n1 * n2)
    # print(f"Effect Size (r): {effect_size_r}")
    #
    # # Display Test Results
    # print("Mann-Whitney U statistic:", stat)
    # print("p-value:", p_val)
    #
    # # Judgement based on the results
    # alpha = 0.05
    # if p_val < alpha:
    #     print("There is a significant difference in the fitness of the 2 event logs.".format(alpha))
    # else:
    #     print("No significant difference in the fitness of the 2 event logs.".format(alpha))


    ############ Step 7 Get the avgfitness of each group ###############

    # calculate fitness of minority and majority groups
    fitness1 = pm4py.fitness_alignments(minority, net, initial_marking, final_marking)
    fitness2 = pm4py.fitness_alignments(majority, net, initial_marking, final_marking)

    # Convert average fitness to percentage with one decimal place
    avg1 = round(fitness1['averageFitness'] * 100, 2)
    avg2 = round(fitness2['averageFitness'] * 100, 2)

    # Convert the percentage to a string and intercept the first digit after the percentage
    avg_str1 = "{:.2f}%".format(avg1)
    avg_str2 = "{:.2f}%".format(avg2)

    # Show the result
    print("Avgfitness of minority: ", avg_str1)
    print("Avgfitness of majority: ", avg_str2)
