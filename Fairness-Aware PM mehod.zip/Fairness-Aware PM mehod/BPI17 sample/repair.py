import pm4py
# from pm4py.objects.petri_net import semantics
#
# from pm4py.algo.discovery.inductive import algorithm as inductive_miner
# from pm4py.algo.conformance.alignments.petri_net import algorithm as alignments
# from pm4py.algo.evaluation.replay_fitness import algorithm as replay_fitness
# from scipy.stats import mannwhitneyu
# from pm4py.objects.conversion.process_tree import converter as process_tree_converter
# from pm4py.visualization.petri_net import visualizer as pn_visualizer
# from pm4py.objects.log.util import dataframe_utils
# from pm4py.objects.petri_net import utils
# # from pm4py.objects.conversion.process_tree import factory as process_tree_factory
# # from pm4py.visualization.process_tree import factory as pt_vis_factory
# import pandas as pd
# from collections import defaultdict
from pm4py.objects.petri_net.obj import PetriNet, Marking
from pm4py.objects.petri_net.utils import petri_utils
from pm4py.visualization.petri_net import visualizer as pn_visualizer

def add_tau(index,net,tname):
    all_tau = []

    for t in tname:

        input_place = get_input_places(net, t)
        # print("Input Places for Transition", tname, ":", input_place)
        output_place = get_output_places(net, t)
        # print("Output Places for Transition", tname, ":", output_place)

        # get the object of the place
        input_places_objects = [place for place in net.places if place.name in input_place]
        output_places_objects = [place for place in net.places if place.name in output_place]

        # add a new transition
        t_1 = PetriNet.Transition("tau_"+str(index), "None")
        net.transitions.add(t_1)

        # add the arc for the transition
        for input_obj in input_places_objects:
            petri_utils.add_arc_from_to(input_obj, t_1, net)
        for output_obj in output_places_objects:
            petri_utils.add_arc_from_to(t_1, output_obj, net)

        all_tau.append(t_1)
        index +=1
    # pm4py.view_petri_net(net, initial_marking, final_marking)

    return all_tau,net

def get_input_places(net, target_transition):
    input_places = []

    # 遍历 Petri 网络中的每个变迁
    for transition in net.transitions:
        # 找到指定的变迁
        if transition.label == target_transition:
            # 遍历该变迁的每个入弧
            for arc in transition.in_arcs:
                # 将源位置的名称添加到输入位置列表中
                input_places.append(arc.source.name)

    return input_places

def get_output_places(net, target_transition):
    output_places = []

    # 遍历 Petri 网络中的每个变迁
    for transition in net.transitions:
        # 找到指定的变迁
        if transition.label == target_transition:
            # 遍历该变迁的每个入弧
            for arc in transition.out_arcs:
                # 将源位置的名称添加到输入位置列表中
                output_places.append(arc.target.name)

    return output_places




