import pm4py
from pm4py.algo.discovery.inductive import algorithm as inductive_miner
from pm4py.algo.conformance.alignments.petri_net import algorithm as alignments
from pm4py.algo.evaluation.replay_fitness import algorithm as replay_fitness
from pm4py.objects.conversion.process_tree import converter as process_tree_converter
from pm4py.algo.conformance.alignments.petri_net import algorithm as alignments
from pm4py.visualization.petri_net import visualizer as pn_visualizer
from scipy.stats import mannwhitneyu

from collections import defaultdict

# log = pm4py.read_xes("fair/Hiring_All.xes.xes")

def model_discovery():

    log = pm4py.read_xes("Hiring/Hiring_All.xes")

    # Use inductive miner create model
    process_tree = inductive_miner.apply(log, variant=inductive_miner.Variants.IMf, parameters={"noise_threshold": 0.2})

    net, initial_marking, final_marking = process_tree_converter.apply(process_tree)

    return net, initial_marking, final_marking

def alignment_cal(log1,log2,net, initial_marking, final_marking,parameters = None):
    # Calculation of alignment
    if parameters is None:
        # print("parameter is none")
        aligned_log1 = alignments.apply_log(log1, net, initial_marking, final_marking)
        # print(aligned_traces1)
        aligned_log2 = alignments.apply_log(log2, net, initial_marking, final_marking)
        # print(aligned_traces2)
    else:
        aligned_log1 = alignments.apply_log(log1, net, initial_marking, final_marking, parameters=parameters)
        aligned_log2 = alignments.apply_log(log2, net, initial_marking, final_marking, parameters=parameters)

    return aligned_log1, aligned_log2

def Mann_test(aligned_traces1, aligned_traces2):
    # Create an empty list of the fitness values for each trace in the 2 event logs.
    trace_fitness_values1 = []
    trace_fitness_values2 = []

    # Iterate over each trace, calculate its fitness value and s?tore it in a list.
    for trace in aligned_traces1:
        trace_fitness = replay_fitness.evaluate([trace], variant=replay_fitness.Variants.ALIGNMENT_BASED)
        trace_fitness_values1.append(trace_fitness['average_trace_fitness'])

    for trace in aligned_traces2:
        trace_fitness = replay_fitness.evaluate([trace], variant=replay_fitness.Variants.ALIGNMENT_BASED)
        trace_fitness_values2.append(trace_fitness['average_trace_fitness'])

    # Calculation with mannwhitneyu
    stat, p_val = mannwhitneyu(trace_fitness_values1, trace_fitness_values2)

    return stat, p_val

