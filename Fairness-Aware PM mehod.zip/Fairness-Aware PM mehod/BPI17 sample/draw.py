import pm4py
import os
import model
import repair
import numpy as np
import matplotlib.pyplot as plt

from pm4py.algo.evaluation.replay_fitness import algorithm as replay_fitness

from pm4py.visualization.petri_net import visualizer as pn_visualizer
from pm4py.algo.evaluation.replay_fitness import algorithm as replay_fitness
from pm4py.objects.petri_net.obj import PetriNet, Marking
from pm4py.objects.petri_net.utils import petri_utils
from pm4py.objects.conversion.log import converter as log_converter
import pandas as pd
from pm4py.objects.log.importer.xes import importer as xes_importer
from pm4py.convert import convert_to_dataframe
from scipy.stats import wilcoxon
from pm4py.algo.conformance.alignments.petri_net import algorithm as alignments


def draw(align_result1, align_result2):


    ############### Step 1 Store all fitness to array #################

    # Declare fitness_values1 to put all fitness in the log1
    fitness_values1 = []
    for alignment1 in align_result1:
        if alignment1['fitness'] <= 1.0:
            fitness_values1.append(alignment1['fitness'])
        else:
            print(alignment1)

    # Declare fitness_values2 to put all fitness in the log2
    fitness_values2 = []
    for alignment2 in align_result2:
        if alignment2['fitness'] <= 1.0:
            fitness_values2.append(alignment2['fitness'])
        else:
            print(alignment2)

    #################### Step 2 Calculate all statistics ######################

    # Calculate quartiles and other statistics for Log1
    q1_1, median_1, q3_1 = np.percentile(fitness_values1, [25, 50, 75])
    minimum_1, maximum_1 = np.min(fitness_values1), np.max(fitness_values1)
    # print("align1 " + str(q1_1) + " " + str(minimum_1) + " " + str(median_1) + " " + str(q3_1) + " " + str(maximum_1))

    # Calculate quartiles and other statistics for Log2
    q1_2, median_2, q3_2 = np.percentile(fitness_values2, [25, 50, 75])
    minimum_2, maximum_2 = np.min(fitness_values2), np.max(fitness_values2)
    # print("align2 " + str(q1_2) + " " + str(minimum_2) + " " + str(median_2) + " " + str(q3_2) + " " + str(maximum_2))

    #################### Step 3 Set up Chart Appearance ######################

    # Create a figure and axis object
    fig, ax = plt.subplots(figsize=(5, 4), sharex=True, sharey=True)

    # Set y-axis top to 1.0
    ax.set_ylim(top=1.00)

    # Boxplot for alignment 1
    bp1 = ax.boxplot(fitness_values1, positions=[1], widths=0.5, showfliers=True, patch_artist=True,
                     boxprops=dict(facecolor='#DF6C5C'), medianprops=dict(color='white'))

    # Boxplot for alignment 2
    bp2 = ax.boxplot(fitness_values2, positions=[2], widths=0.5, showfliers=True, patch_artist=True,
                     boxprops=dict(facecolor='#59A6A9'), medianprops=dict(color='white'))

    # Set up the title and Spacing between titles and figures
    ax.set_title('Hospital - Original', pad=12, fontsize=14)
    ax.set_ylabel('Fitness')
    ax.grid(True)

    #################### Step 4 Labels and numbers to identify figure ######################

    # Create array to store all statistics
    positions1 = [maximum_1, q3_1, median_1, q1_1, minimum_1]
    positions2 = [maximum_2, q3_2, median_2, q1_2, minimum_2]
    labels = ['Max', 'Q3', 'Median', 'Q1', 'Min']

    # Adjust the position with the same value for Log 1
    prev_y1_values = []
    for i, (y1, label) in enumerate(zip(positions1, labels)):
        adjusted_y1 = y1
        for prev_y1 in prev_y1_values:
            # The difference between the positions to be displayed for the two values is less than 0.05
            if abs(adjusted_y1 - prev_y1) < 0.05:
                # The position displayed by the second numerical value is 0.04 downwards
                adjusted_y1 -= 0.04
        # Make statistic values appear as percentages
        y1_rounded = int(y1 * 100) / 100
        ax.text(1, adjusted_y1, f'{label}: {y1_rounded}', fontsize=10, va='center', ha='center', color='black')
        prev_y1_values.append(adjusted_y1)

    # Adjust the position with the same value for Log 2
    prev_y2_values = []
    for i, (y2, label) in enumerate(zip(positions2, labels)):
        adjusted_y2 = y2
        for prev_y2 in prev_y2_values:
            if abs(adjusted_y2 - prev_y2) < 0.05:
                adjusted_y2 -= 0.04
        # ax.text(2, adjusted_y2, f'{label}: {adjusted_y2:.1f}', fontsize=10, va='center', ha='center', color='black')
        # adjusted_y2_rounded = int(adjusted_y2 * 100) / 100
        y2_rounded = int(y2 * 100) / 100
        ax.text(2, adjusted_y2, f'{label}: {y2_rounded}', fontsize=10, va='center', ha='center', color='black')
        prev_y2_values.append(adjusted_y2)

    #################### Step 5 Adjust boxplot display content  ######################

    # Set the X-axis to display two groups
    ax.set_xticklabels(['Minority', 'Majority'])

    # Adjust graphic position
    plt.subplots_adjust(bottom=0.1, top=0.9)

    # Change the color of x-axis tick labels (Log1)
    plt.gca().get_xticklabels()[0].set_color('#FFFFFF')  # First tick label color
    plt.gca().get_xticklabels()[0].set_backgroundcolor('#DF6C5C')  # First tick label background color

    # Change the color of x-axis tick labels (Log2)
    plt.gca().get_xticklabels()[1].set_color('#FFFFFF')  # Second tick label
    plt.gca().get_xticklabels()[1].set_backgroundcolor('#59A6A9')

    # plt.tight_layout()

    #################### Step 6 Save & Show boxplot into the file ######################

    output_file_path = 'Result/Hospital/original.png'
    plt.savefig(output_file_path)
    plt.show()

    return fitness_values1,fitness_values2


